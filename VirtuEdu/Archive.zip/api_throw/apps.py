from django.apps import AppConfig


class ApiThrowConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api_throw'
